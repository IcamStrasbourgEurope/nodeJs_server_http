<?php
    $IP_ADDRESS = "10.0.2.6";
    $PORT = 3000;
    $URL_GET_CLIENTS = 'http://' . $IP_ADDRESS . ':' . $PORT . '/clients';
    $URL_GET_NB_VENTES = 'http://' . $IP_ADDRESS .':' . $PORT . '/nbVentes';
?>