<?php
    require 'config.php';
    ini_set("allow_url_fopen", 1);
    
    $nombreVentesRaw = file_get_contents($URL_GET_NB_VENTES);
    $nombreVentesRaw = json_decode($nombreVentesRaw);
    $nombreVentes = $nombreVentesRaw->nombre_vente;

    $clientsRaw = file_get_contents($URL_GET_CLIENTS);
    $clientsRaw = json_decode($clientsRaw);
    $clients = $clientsRaw;
?>


<!DOCTYPE html>
<HTML lang="fr">
	<HEAD>

		<meta charset="utf-8" />
		
		<LINK rel="stylesheet" type="text/css" href="style/style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

		<title>Mon Dashboard</title>
	</HEAD>

	<BODY>
        <div class="bg-frame">
            <div class="bg-text main-title">
                Mon Dashboard
            </div>

            <div class="bg-text">
                Nombre de ventes : <?php echo $nombreVentes ?>
            </div>

            <div class="bg-text ">
                Nos clients

                <div class="bg-text ">
                    <?php foreach($clients as $client): ?>
                        <span><?= $client->nom; ?></span>
                        </br>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
	</BODY>
</HTML>