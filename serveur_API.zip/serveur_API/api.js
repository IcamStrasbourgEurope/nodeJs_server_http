// On appelle les bibliothèques et fonctions extérieures
const EXPRESS = require('express');
const CONNECTION = require('./clients').CONNECTION

// On défini nos constantes
const PORT = 3000; // Définission du port
const API = EXPRESS(); // Création de l'application qui nous sert d'API

// Ressources par défaut
API.get('/', (request, response) => {
        response.send('Hello World');
    }
)

// Ressources - Liste des clients
API.get('/clients', (request, response) => {
        let sqlQuery = 'SELECT * FROM clients';
        CONNECTION.query(sqlQuery, (error, results, fields) => {
            let clientsList = JSON.stringify(results);
            response.send(clientsList);
        });        
    }
)

// Ressource - Nombre de ventes
API.get('/nbVentes', (request, response) => {
        let sqlQuery = 'SELECT nombre_vente FROM clients';
        CONNECTION.query(sqlQuery, (error, results, fields) => {
            let nbVentesTotal = 0;
            results.forEach(vente => {
                nbVentesTotal += vente.nombre_vente;
            });

            response.send({nombre_vente:nbVentesTotal});
        });        
    }
)

// On ordonne à l'application d'écouter les requêtes sur le PORT indiqué plus haut
API.listen(PORT, () => {
        console.log("Application back-end d\'exemple ecoutant sur le port : " + PORT);
    }
)