const MYSQL = require('mysql')

// On défini l'accès à la BDD (Attention, non sécurisé)
const CONNECTION = MYSQL.createConnection({
    host:'10.0.2.5',
    port:3306,
    user:'server_back',
    password:'tssr2023',
    database:'gestion_entreprise',
    insecureAuth:true
})

// On se connecte à la BDD et on gère le cas où on a une erreur
CONNECTION.connect(function(error) {
    if (error) {
        return console.error('error: ' + error.message);
    }

    console.log('Connected to the MySQL server')
})

// On rend la connexion disponible aux autres fichier .js
module.exports = {
    CONNECTION: CONNECTION
}